// ELSHA Bangladesh Store — JavaScript
// Demo storefront only: cart works in the browser, but orders/payments are NOT sent to a server.

const products = [
  {
    name: "Soft Rose Midi Dress",
    price: 2490,
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=200&q=70"
  },
  {
    name: "Everyday Linen Dress",
    price: 2850,
    image: "https://images.unsplash.com/photo-1566206091558-7f218b696731?auto=format&fit=crop&w=200&q=70"
  },
  {
    name: "Petal Handmade Crochet Top",
    price: 1650,
    image: "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=200&q=70"
  },
  {
    name: "Elsha Evening Dress",
    price: 3490,
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=200&q=70"
  }
];

let cart = [];

const formatBDT = (amount) => "৳ " + amount.toLocaleString("en-BD");

function addToCart(productIndex) {
  if (!products[productIndex]) return;
  cart.push(productIndex);
  renderCart();

  const toast = document.getElementById("toast");
  if (toast) {
    toast.textContent = "Added to bag";
    toast.classList.add("show");
    window.setTimeout(() => toast.classList.remove("show"), 1400);
  }
}

function renderCart() {
  const count = document.getElementById("bagcount");
  const content = document.getElementById("cartcontent");
  const subtotalElement = document.getElementById("subtotal");

  const subtotal = cart.reduce((sum, productIndex) => {
    return sum + products[productIndex].price;
  }, 0);

  if (count) count.textContent = String(cart.length);
  if (subtotalElement) subtotalElement.textContent = formatBDT(subtotal);

  if (content) {
    if (cart.length === 0) {
      content.innerHTML = '<p class="empty">Your bag is empty.</p>';
    } else {
      content.innerHTML = cart.map((productIndex, cartIndex) => {
        const product = products[productIndex];
        return `
          <div class="cartrow">
            <img src="${product.image}" alt="${product.name}">
            <div style="flex:1">
              <h4>${product.name}</h4>
              <small>${formatBDT(product.price)}</small>
              <div class="qty">
                <button type="button" onclick="decreaseQuantity(${cartIndex})" aria-label="Decrease quantity">−</button>
                <span>1</span>
                <button type="button" onclick="increaseQuantity(${cartIndex})" aria-label="Increase quantity">+</button>
                <button type="button" class="remove" onclick="removeCartItem(${cartIndex})">Remove</button>
              </div>
            </div>
          </div>`;
      }).join("");
    }
  }

  updateCheckoutTotal();
}

function increaseQuantity(cartIndex) {
  if (cartIndex < 0 || cartIndex >= cart.length) return;
  cart.push(cart[cartIndex]);
  renderCart();
}

function decreaseQuantity(cartIndex) {
  if (cartIndex < 0 || cartIndex >= cart.length) return;
  cart.splice(cartIndex, 1);
  renderCart();
}

function removeCartItem(cartIndex) {
  if (cartIndex < 0 || cartIndex >= cart.length) return;
  cart.splice(cartIndex, 1);
  renderCart();
}

function openCart() {
  document.getElementById("drawer")?.classList.add("open");
  document.getElementById("overlay")?.classList.add("show");
}

function closeCart() {
  document.getElementById("drawer")?.classList.remove("open");
  document.getElementById("overlay")?.classList.remove("show");
}

function openCheckout() {
  if (cart.length === 0) {
    alert("Please add a product to your bag first.");
    return;
  }
  closeCart();
  document.getElementById("checkout")?.classList.add("show");
  updateCheckoutTotal();
}

function closeCheckout() {
  document.getElementById("checkout")?.classList.remove("show");
}

function updateCheckoutTotal() {
  const totalElement = document.getElementById("checkouttotal");
  const areaElement = document.getElementById("area");
  if (!totalElement || !areaElement) return;

  const subtotal = cart.reduce((sum, productIndex) => {
    return sum + products[productIndex].price;
  }, 0);

  // Sample delivery rates only. Confirm your courier's actual rates before launch.
  const deliveryFee = areaElement.value === "inside" ? 80 : 130;
  totalElement.textContent =
    formatBDT(subtotal + deliveryFee) +
    " (delivery " + formatBDT(deliveryFee) + ")";
}

function submitOrder(event) {
  event.preventDefault();

  if (cart.length === 0) {
    alert("Your bag is empty.");
    closeCheckout();
    return;
  }

  const form = event.currentTarget;
  const formData = new FormData(form);
  const paymentMethod = formData.get("payment");

  // Online payment is deliberately blocked until a real payment gateway is integrated.
  if (paymentMethod !== "Cash on Delivery") {
    alert(
      paymentMethod +
      " payment is not connected yet. Integrate an approved merchant payment gateway before accepting online payments. For this demo, please select Cash on Delivery."
    );
    return;
  }

  const deliveryFee = formData.get("area") === "inside" ? 80 : 130;
  const subtotal = cart.reduce((sum, productIndex) => {
    return sum + products[productIndex].price;
  }, 0);

  const order = {
    orderReference: "ELSHA-DEMO-" + Date.now(),
    customer: {
      name: formData.get("name"),
      phone: formData.get("phone"),
      address: formData.get("address"),
      district: formData.get("district")
    },
    items: cart.map((productIndex) => ({
      name: products[productIndex].name,
      price: products[productIndex].price
    })),
    subtotal,
    deliveryFee,
    total: subtotal + deliveryFee,
    paymentMethod
  };

  // Demo only: this displays order details in the browser.
  // It does not save or send the order to ELSHA.
  alert(
    "Demo order prepared. No order has been sent to the store.\n\n" +
    "Customer: " + order.customer.name + "\n" +
    "Phone: " + order.customer.phone + "\n" +
    "Items: " + order.items.length + "\n" +
    "Total: " + formatBDT(order.total)
  );

  console.log("ELSHA demo order:", order);
  cart = [];
  renderCart();
  closeCheckout();
  form.reset();
}

function subscribeToNewsletter(event) {
  event.preventDefault();
  alert("Thank you for your interest in ELSHA! Connect an email marketing service to store subscribers.");
  event.currentTarget.reset();
}

// Connect the HTML form events once the page has loaded.
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("orderform")?.addEventListener("submit", submitOrder);
  const newsletterForm = document.querySelector(".signup");
  newsletterForm?.addEventListener("submit", subscribeToNewsletter);

  document.getElementById("area")?.addEventListener("change", updateCheckoutTotal);

  renderCart();
});

// Compatibility aliases for the onclick attributes in the supplied HTML.
window.add = addToCart;
window.openCart = openCart;
window.closeCart = closeCart;
window.showCheckout = openCheckout;
window.hideCheckout = closeCheckout;
window.changeQty = (index, direction) => {
  if (direction > 0) increaseQuantity(index);
  else decreaseQuantity(index);
};
window.removeItem = removeCartItem;
window.updateTotal = updateCheckoutTotal;
window.placeOrder = submitOrder;
window.subscribe = subscribeToNewsletter;
